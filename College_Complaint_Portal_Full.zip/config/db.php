
<?php
$conn = new mysqli("localhost","root","","complaint_portal");
if($conn->connect_error){
    die("Connection Failed");
}
?>
