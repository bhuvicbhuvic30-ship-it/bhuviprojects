
<?php
include("../config/db.php");
$conn->query("INSERT INTO complaints(title,description,user_id) VALUES('$_POST[title]','$_POST[description]',1)");
echo "Submitted";
?>
