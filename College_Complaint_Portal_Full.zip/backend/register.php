
<?php
include("../config/db.php");
$conn->query("INSERT INTO users(name,email,password,role) VALUES('$_POST[name]','$_POST[email]','$_POST[password]','student')");
echo "Registered";
?>
