
CREATE DATABASE complaint_portal;
USE complaint_portal;

CREATE TABLE users(
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(100),
email VARCHAR(100),
password VARCHAR(100),
role VARCHAR(20)
);

CREATE TABLE complaints(
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
title VARCHAR(200),
description TEXT,
status VARCHAR(50) DEFAULT 'Pending'
);
