
<?php
include("../config/db.php");
$res=$conn->query("SELECT * FROM complaints");
while($row=$res->fetch_assoc()){
echo $row['title']." - ".$row['status']."<br>";
}
?>
