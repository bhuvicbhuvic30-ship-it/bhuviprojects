
<?php include("../config/db.php"); ?>
<form action="../backend/submit_complaint.php" method="POST">
<input name="title"><br>
<textarea name="description"></textarea><br>
<button>Submit</button>
</form>
